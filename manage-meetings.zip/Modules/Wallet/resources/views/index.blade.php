<x-wallet::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('wallet.name') !!}</p>
</x-wallet::layouts.master>
